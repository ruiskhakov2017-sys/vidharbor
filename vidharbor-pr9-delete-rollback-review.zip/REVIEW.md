# PR #9: восстановление удаления после rollback

HEAD остаётся 60102eea8e3331fa0198239d03d5c295b2f88b73, ветка feature/s05-s08-completion. Изменения локальны, не staged; commit/push/изменение PR/merge/deployment не выполнялись. Изменены только api/vidharbor/deletion.py и api/vidharbor/test_deletion.py.

## Воспроизведение

До изменения кода приложения добавлен отдельный Django-тест: настоящее journal.append/fsync и revoke внутри PostgreSQL-транзакции, затем управляемый rollback. Журнал сохранил intent, но БД осталась READY, оригинал существовал. Обычный cleanup_uploads не исправил состояние: тест FAIL READY != DELETED. Доступ уже закрывался по журналу; дефект состоял в незавершающейся уборке и несогласованном состоянии БД/доставки. Лог red.log, exit=1.

## Исправление

clean_pending перед выборкой DELETING читает durable-журнал и вызывает существующий revoke для существующих роликов, которые ещё не DELETING/DELETED. Lock журнала освобождается до Video row lock. Повтор использует прежний intent/время/ID; generation не расходуется повторно. Затем действует прежняя очистка под flock. apply_journal делегирует тому же пути, исключая отдельную дублирующую реализацию replay. cleanup_uploads и расписание не изменялись.

## Проверки

- Два новых теста: PASS, отдельно после исходного RED; green.log.
- Полный Django/PostgreSQL: 74 PASS, 0 FAIL, 19.664 с.
- Миграции: No changes detected.
- GNU timeout/coreutils 9.11 supervisor: 3 PASS, 0 FAIL.
- Restore guards: 5 PASS, 0 FAIL. Все эти проверки: regression.log.
- Интеграция: отдельная PostgreSQL/медиатом/journal, реальные процессы FFmpeg и два successive cleanup_uploads --watch. Готовый ролик после rollback остаётся READY в БД, но новые публичные запросы получают 404. Первый уборщик автоматически применяет журнал и удаляет его, отменяет SENDING Delivery. Для второго PROCESSING fixture FFmpeg реально держит flock и продолжает писать; после rollback уборщик переводит БД в DELETING/Job CANCELLED, но не удаляет файлы до освобождения lock. Уборщик перезапущен (PID 32 → 39), lock inode сохранён. После остановки FFmpeg автоматическая очистка достигает DELETED. Повтор команды идемпотентен, намерения удаления не изменены, старый worker не публикует READY, новых Job/событий/Delivery нет, поздний ACK проигнорирован. Логи integration.log/integration.json; restore-команда не использовалась.
- Это целевая интеграция на подготовленных записях с настоящими PG/filesystem/FFmpeg, не повтор полного browser/queue e2e. Реальные n8n/Sheets не использовались.
- git diff --check PASS; фактические временные секреты в patch отсутствуют. Изменений S07, CI, схемы или других документов нет.

## Основные команды

На отдельном Compose project vidharbor-delete-rollback-review с собственными секретами и DB_NAME=vidharbor_delete_rollback_test:

```sh
python manage.py test vidharbor.test_deletion.DeletionTests.test_cleanup_command_recovers_journaled_delete_after_transaction_rollback --noinput --verbosity 2
python manage.py test vidharbor --noinput
python manage.py makemigrations --check --dry-run
PYTHONPATH=/app python /review/smoke_s04_supervisor.py
python3 scripts/test_s08.py
```

Интеграционный harness integration.py выполнялся через отдельный upload-контейнер со stdin; он входит в пакет как доказательство, в репозиторий не добавлен. Тестовый PostgreSQL остановлен после проверки, его тома и данные сохранены. Прежние проекты/ветки/данные не изменялись. Полный точный diff: vidharbor-delete-rollback-fix.patch.
