"""Targeted integration fixture: PostgreSQL, real FFmpeg flock, cleaner restart."""
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
from io import StringIO
from pathlib import Path

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'vidharbor.settings')
import django
django.setup()
from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.db import transaction
from django.test import Client
from django.utils import timezone
from vidharbor import journal
from vidharbor.deletion import revoke
from vidharbor.job_attempts import begin_attempt, finish_attempt
from vidharbor.models import Attempt, Delivery, Job, Outbox, ReadyEvent, ReceiverRow, Upload, Video
from vidharbor.notifications import attach_existing_ready, claim, finish
from vidharbor.publication import publish_video, ready_path, staging_path
from vidharbor.storage import media_lock, original_path

assert settings.DATABASES['default']['NAME'] == 'vidharbor_delete_rollback_test'
assert not Video.objects.exists(), 'Use the new isolated integration database'
report = {'status': 'RUNNING', 'scope': 'targeted DB/filesystem/FFmpeg/cleaner process integration; no external services'}
writer = cleaner = None
handles = []

def wait_for(predicate, label, seconds=15):
    deadline = time.monotonic() + seconds
    while not predicate():
        assert time.monotonic() < deadline, label
        time.sleep(.1)

def state(video):
    video.refresh_from_db()
    return video.state

def start_cleaner(number):
    log = Path('/tmp') / f'rollback-cleaner-{number}.log'
    handle = log.open('w'); handles.append(handle)
    return subprocess.Popen([sys.executable, 'manage.py', 'cleanup_uploads', '--watch'], stdout=handle, stderr=subprocess.STDOUT)

def rolled_back_delete(video):
    with transaction.atomic():
        revoke(video.id)
        transaction.set_rollback(True)
    video.refresh_from_db()
    assert video.generation == 1 and video.deleted_at is None
    assert journal.is_deleted(video.id) and original_path(video.upload_id).exists()

try:
    owner = get_user_model().objects.create_user(username='rollback-' + uuid.uuid4().hex[:8])
    fixture = Path('/fixtures/landscape.mp4')
    digest = hashlib.sha256(fixture.read_bytes()).hexdigest()
    def make_video(ready):
        upload = Upload.objects.create(owner=owner, title='Rollback integration', expected_size=fixture.stat().st_size,
            size=fixture.stat().st_size, sha256=digest, state='COMPLETE')
        video = Video.objects.create(owner=owner, upload=upload, title=upload.title,
            state='READY' if ready else 'QUEUED', published_generation=1 if ready else None)
        shutil.copyfile(fixture, original_path(upload.pk))
        job = Job.objects.create(video=video, generation=1, state='SUCCEEDED' if ready else 'PROCESSING')
        attempt = Attempt.objects.create(job=job, number=1, state='SUCCEEDED' if ready else 'RUNNING')
        return video, job, attempt

    published, _, _ = make_video(True)
    event_id = uuid.uuid4()
    source = Outbox.objects.create(message_id=event_id, job=Job.objects.get(video=published), kind='video.ready', attempt_no=0,
        payload={'type':'video.ready','version':1,'event_id':str(event_id),'video_id':str(published.id),
                 'title':published.title,'ready_at':timezone.now().isoformat(),
                 'playlist_url':f'https://video.example.invalid/media/{published.id}/master.m3u8'})
    assert attach_existing_ready() == 1
    sending = claim(event_id); assert sending is not None
    initial_snapshot = ReadyEvent.objects.get(pk=event_id).payload
    rolled_back_delete(published)
    assert published.state == 'READY'
    assert Delivery.objects.get(pk=event_id).state == 'SENDING'
    client = Client(HTTP_HOST='localhost')
    for path in (f'/watch/{published.id}',f'/media/{published.id}/master.m3u8'):
        assert client.get(path).status_code == 404
    report['ready_rollback'] = {'db_state':'READY','durable_intent':True,'original_present':True,'public_requests':404}

    processing, job, attempt = make_video(False)
    directory = staging_path(processing.id); directory.mkdir(parents=True)
    output = directory / 'live.ts'
    lock = settings.MEDIA_ROOT / 'locks' / str(processing.id)
    writer_log = Path('/tmp/rollback-ffmpeg.log').open('w'); handles.append(writer_log)
    with lock.open('ab') as descriptor:
        fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
        inode = lock.stat().st_ino
        writer = subprocess.Popen(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-re','-stream_loop','-1',
            '-i',str(original_path(processing.upload_id)),'-t','90','-an','-c:v','libx264','-preset','ultrafast',
            '-f','mpegts',str(output)],pass_fds=(descriptor.fileno(),),start_new_session=True,
            stdout=subprocess.DEVNULL,stderr=writer_log)
    wait_for(lambda: output.exists() and output.stat().st_size > 0,'FFmpeg did not write')
    with media_lock(processing.id) as acquired: assert not acquired, 'FFmpeg did not inherit the lock'
    rolled_back_delete(processing)
    assert processing.state == 'QUEUED'
    intents = {str(v.id):journal.deletion_record(v.id) for v in (published,processing)}

    cleaner = start_cleaner(1); first_pid = cleaner.pid
    wait_for(lambda: state(published)=='DELETED' and state(processing)=='DELETING','cleaner failed to replay intents')
    job.refresh_from_db(); attempt.refresh_from_db()
    assert (job.state,attempt.state)==('CANCELLED','FAILED')
    assert Delivery.objects.get(pk=event_id).state=='CANCELLED'
    assert not original_path(published.upload_id).exists()
    assert original_path(processing.upload_id).exists() and directory.exists()
    assert writer.poll() is None and lock.stat().st_ino==inode
    before = output.stat().st_size
    time.sleep(1)
    assert writer.poll() is None and output.stat().st_size > before
    cleaner.terminate(); cleaner.wait(timeout=5)
    cleaner = start_cleaner(2); assert cleaner.pid != first_pid
    time.sleep(.5)
    assert cleaner.poll() is None and state(processing)=='DELETING'
    assert original_path(processing.upload_id).exists() and writer.poll() is None
    report['live_ffmpeg'] = {'pid':writer.pid,'flock_held':True,'output_grew':True,'files_preserved_while_locked':True,
        'cleaner_pids':[first_pid,cleaner.pid],'state_after_restart':'DELETING','job':'CANCELLED','attempt':'FAILED'}

    finish_attempt(attempt.pk,'success',{},publish=publish_video)
    assert begin_attempt(job.pk,1,2,{}) is None
    finish(sending,'written'); assert claim(event_id) is None
    assert attach_existing_ready()==0
    assert Outbox.objects.filter(job=job,kind='video.ready').count()==0
    writer.terminate();writer.wait(timeout=10)
    wait_for(lambda: state(processing)=='DELETED','cleanup did not finish after FFmpeg released flock')
    assert not original_path(processing.upload_id).exists() and not directory.exists()
    assert not ready_path(processing.id,1).parent.exists() and lock.stat().st_ino==inode
    settled = {str(v.pk):(v.generation,v.deleted_at) for v in Video.objects.all()}
    call_command('cleanup_uploads',stdout=StringIO())
    assert {str(v.pk):(v.generation,v.deleted_at) for v in Video.objects.all()}==settled
    for v in (published,processing):assert journal.deletion_record(v.pk)==intents[str(v.pk)]
    assert (Job.objects.count(),Attempt.objects.count(),Outbox.objects.count(),ReadyEvent.objects.count(),Delivery.objects.count(),ReceiverRow.objects.count())==(2,2,1,1,1,0)
    assert ReadyEvent.objects.get(pk=event_id).payload==initial_snapshot
    assert Delivery.objects.get(pk=event_id).state=='CANCELLED'
    report.update(status='PASS',final_states=list(Video.objects.order_by('id').values_list('state',flat=True)),
        deletion_intents=sum(e['kind']=='delete' for e in journal.read_entries()[0]),
        no_republication=True,no_new_notifications=True,late_ack_ignored=True,idempotent=True,restore_command_used=False)
except Exception as exc:
    report.update(status='FAIL',error=repr(exc));raise
finally:
    for process in (writer,cleaner):
        if process is not None and process.poll() is None:
            process.terminate()
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
    for handle in handles:handle.close()
    for name in ('rollback-ffmpeg.log','rollback-cleaner-1.log','rollback-cleaner-2.log'):
        path=Path('/tmp')/name
        if path.exists():print(name+': '+path.read_text()[-2000:],flush=True)
    print(json.dumps(report,default=str),flush=True)
