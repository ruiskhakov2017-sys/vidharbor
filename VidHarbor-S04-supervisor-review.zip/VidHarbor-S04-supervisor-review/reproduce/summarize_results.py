import json,os
from pathlib import Path
os.environ.setdefault('DJANGO_SETTINGS_MODULE','vidharbor.settings')
import django
django.setup()
from django.conf import settings
from vidharbor.models import Job, Outbox
from vidharbor.storage import original_path, file_digest
from vidharbor import publication
assert settings.DATABASES['default']['NAME']=='vidharbor_s04_test'
fixture_hash=file_digest(Path('/fixtures/landscape.mp4'))
result=[]
for job in Job.objects.select_related('video__upload').order_by('video__created_at'):
    attempts=list(job.attempts.order_by('number').values('number','state','reason'))
    original=original_path(job.video.upload_id)
    corrupt=any(a['reason']=='invalid_video' for a in attempts)
    digest=file_digest(original)
    assert Job.objects.filter(video=job.video).count()==1
    assert job.generation==1 and job.video.generation==1
    assert corrupt or digest==fixture_hash
    events=list(Outbox.objects.filter(job=job,kind=publication.READY_EVENT).values_list('message_id',flat=True))
    assert len(events)==(1 if job.state=='SUCCEEDED' else 0)
    if job.state=='SUCCEEDED':
        attempt=job.attempts.get(state='SUCCEEDED')
        publication.verify_manifest(publication.ready_path(job.video_id,1),job,attempt.pk)
    result.append({'job_id':str(job.id),'video_id':str(job.video_id),'generation':job.generation,
                   'state':job.state,'attempts':attempts,'ready_events':list(map(str,events)),
                   'original_sha256':digest,'original_is_fixture':digest==fixture_hash})
print(json.dumps({'fixture_sha256':fixture_hash,'jobs':result},indent=2))
