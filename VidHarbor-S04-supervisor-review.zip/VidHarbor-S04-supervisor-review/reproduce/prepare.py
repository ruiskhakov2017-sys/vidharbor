from pathlib import Path
import json,secrets
repo=Path('/workspace/vidharbor-s04-supervisor-fix');root=Path('/workspace/scratch/vidharbor-s04-supervisor')
for component in ('api','web'):
    text=(repo/component/'Dockerfile').read_text()
    for old,new in [('RUN pip install','RUN --mount=type=secret,id=proxy_ca,required=true PIP_CERT=/run/secrets/proxy_ca pip install'),('RUN npm ci','RUN --mount=type=secret,id=proxy_ca,required=true NODE_EXTRA_CA_CERTS=/run/secrets/proxy_ca npm ci'),('RUN apk add','RUN --mount=type=secret,id=proxy_ca,required=true SSL_CERT_FILE=/run/secrets/proxy_ca apk add')]: text=text.replace(old,new)
    text=text.replace('USER 65532:65532','RUN chmod -R a+rX /app\nUSER 65532:65532')
    (root/f'{component}.Dockerfile').write_text(text)
services={}
for name in ('api','upload','migrate','worker','relay','cleanup','web'):
    component='web' if name=='web' else 'api'
    services[name]={'build':{'dockerfile':str(root/f'{component}.Dockerfile'),'secrets':['proxy_ca']}}
    if name in ('api','upload'): services[name]['healthcheck']={'test':['CMD','python','-c',"import urllib.request; urllib.request.urlopen('http://127.0.0.1:8000/health/live',timeout=5).close()"]}
for name in ('upload','worker'):
    services[name]['volumes']=[str(root/'fixtures')+':/fixtures:ro',str(root)+':/review']
(root/'compose.json').write_text(json.dumps({'services':services,'secrets':{'proxy_ca':{'file':'/etc/ssl/certs/ca-certificates.crt'}}},indent=2))
sdir=root/'secrets';sdir.mkdir(mode=0o700,exist_ok=True)
for name in ('django_secret_key','postgres_password','rabbitmq_password'):
    f=sdir/name
    if not f.exists():f.write_text(secrets.token_hex(32));f.chmod(0o444)
(root/'fixtures').mkdir(exist_ok=True);(root/'fixtures').chmod(0o755)
(root/'evidence').mkdir(exist_ok=True);(root/'evidence').chmod(0o777)
root.chmod(0o755)
