"""Evidence-only controller for the unchanged S04 orphan scenario; isolated DB only."""
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import smoke_s04_faults as s

label = sys.argv[1]
root = Path('/review/evidence') / label
root.mkdir(exist_ok=True)

def try_lock(path):
    with path.open('ab') as held:
        try:
            fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        return True

def snapshot(stage, lock, directory, group):
    info = {'stage': stage, 'time': time.time(), 'lock_inode': lock.stat().st_ino,
            'contender_can_lock': try_lock(lock), 'group': group,
            'output_bytes': sum(p.stat().st_size for p in directory.glob('v*/seg-*.ts')), 'processes': []}
    for proc in sorted(Path('/proc').glob('[0-9]*'), key=lambda p: int(p.name)):
        try:
            stat = (proc/'stat').read_text().rsplit(')', 1)[1].split()
            command = (proc/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if not any(n in command for n in ('ffmpeg', 'timeout', 'smoke_s04', 'diagnose.py')):
                continue
            fds = []
            for fd in (proc/'fd').iterdir():
                try:
                    dest = os.readlink(fd)
                    if dest == str(lock) or str(directory) in dest:
                        fds.append({'fd': fd.name, 'target': dest, 'fdinfo': (proc/'fdinfo'/fd.name).read_text()})
                except (FileNotFoundError, PermissionError):
                    pass
            info['processes'].append({'pid': int(proc.name), 'ppid': int(stat[1]), 'pgid': int(stat[2]),
                                      'sid': int(stat[3]), 'state': stat[0], 'exe': os.readlink(proc/'exe'),
                                      'cmd': command, 'fds': fds})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    info['proc_locks'] = [line for line in Path('/proc/locks').read_text().splitlines()
                          if ':'+str(lock.stat().st_ino)+' ' in line]
    (root/(stage+'.json')).write_text(json.dumps(info, indent=2))
    print(json.dumps(info, indent=2), flush=True)
    return info

binary = shutil.which('timeout')
print('TIMEOUT', binary, os.path.realpath(binary), flush=True)
subprocess.run(['timeout','--help'], check=False)
subprocess.run(['apk','info','-W',binary], check=False)
conn, channel = s.relay.connect()
assert channel.queue_declare(queue=s.relay.QUEUE, passive=True).method.consumer_count == 0
processes, start = s.workers_for(root)
group = None
try:
    job, _ = s.make_job(channel)
    source = s.original_path(job.video.upload_id)
    original_hash = s.file_digest(source)
    old, marker, _ = start('orphan')
    directory = s.publication.staging_path(job.video_id)
    s.wait_for(conn, lambda: marker.exists() and any(directory.glob('v*/seg-*.ts')))
    group = int(marker.read_text())
    lock = s.settings.MEDIA_ROOT/'locks'/str(job.video_id)
    initial = snapshot('writer-alive', lock, directory, group)
    assert not initial['contender_can_lock']
    s.stop(old, kill=True)
    new, _, logfile = start('lock-wait')
    s.wait_for(conn, lambda: 'Waiting for media lock' in s.read_log(logfile))
    before = sum(p.stat().st_size for p in directory.glob('v*/seg-*.ts'))
    s.wait_for(conn, lambda: sum(p.stat().st_size for p in directory.glob('v*/seg-*.ts')) > before)
    still = snapshot('worker-dead-writer-alive', lock, directory, group)
    assert not still['contender_can_lock'] and still['output_bytes'] > before
    assert job.attempts.count() == 1
    s.assert_hidden(job)
    os.killpg(group, signal.SIGKILL)
    time.sleep(2)
    stopped = snapshot('group-killed', lock, directory, group)
    if label == 'before':
        assert not stopped['contender_can_lock'], 'Baseline failure did not reproduce'
        holders = [p for p in stopped['processes'] if any('FLOCK' in f['fdinfo'] for f in p['fds'])]
        assert holders and all(p['pgid'] != group for p in holders), holders
        print('REPRODUCED: live timeout outside killed group retains inherited FLOCK', flush=True)
    else:
        s.retry_delivery(conn, channel, job, 'worker_lost')
        s.assert_ready(job, attempts=[('RETRY','worker_lost'),('SUCCEEDED','')])
        assert try_lock(lock)
        assert lock.stat().st_ino == initial['lock_inode']
        assert s.file_digest(source) == original_hash
        print('PASS: writer protected; group exit releases same inode; recovered once; original unchanged', flush=True)
finally:
    if group:
        try: os.killpg(group, signal.SIGKILL)
        except ProcessLookupError: pass
    for process, _ in processes:
        s.stop(process, kill=True)
    conn.close()
