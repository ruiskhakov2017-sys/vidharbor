source /workspace/scratch/vidharbor-s04-supervisor/env.sh
export COMPOSE_PROJECT_NAME=vidharbor-s04-supervisor-after
export VIDHARBOR_PORT=8111
export VIDHARBOR_PUBLIC_BASE_URL=http://127.0.0.1:8111
dc() { docker compose --env-file .env.example -f compose.yaml -f /workspace/scratch/vidharbor-s04-supervisor/compose-after.json "$@"; }
