export COMPOSE_PROJECT_NAME=vidharbor-s04-supervisor
export VIDHARBOR_PORT=8110
export VIDHARBOR_DB_NAME=vidharbor_s04_test
export VIDHARBOR_SECRETS_DIR=/workspace/scratch/vidharbor-s04-supervisor/secrets
export VIDHARBOR_PUBLIC_BASE_URL=http://127.0.0.1:8110
