import os,signal,tempfile,time,fcntl,json
from pathlib import Path
from smoke_s04_faults import make_job,workers_for,wait_for,stop,read_log
from vidharbor.management.commands import relay_outbox as relay
from django.conf import settings
amqp,channel=relay.connect()
assert channel.queue_declare(queue=relay.QUEUE,passive=True).method.consumer_count==0
processes=[]
try:
    with tempfile.TemporaryDirectory() as folder:
        processes,start=workers_for(Path(folder))
        job,message=make_job(channel)
        old,marker,_=start('orphan')
        output=settings.MEDIA_ROOT/'processing'/str(job.video_id)
        wait_for(amqp,lambda:marker.exists() and any(output.glob('v*/seg-*.ts')))
        group=int(marker.read_text())
        stop(old,kill=True)
        new,_,log=start('lock-wait')
        wait_for(amqp,lambda:'Waiting for media lock' in read_log(log))
        os.killpg(group,signal.SIGKILL)
        time.sleep(2)
        retained=False
        with (settings.MEDIA_ROOT/'locks'/str(job.video_id)).open('ab') as lock:
            try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError: retained=True
        holders=[]
        needle=str(settings.MEDIA_ROOT/'locks'/str(job.video_id))
        for proc in Path('/proc').iterdir():
            if not proc.name.isdigit(): continue
            try:
                links=[str(fd.resolve()) for fd in (proc/'fd').iterdir()]
                if needle in links:
                    holders.append({'pid':int(proc.name),'pgid':os.getpgid(int(proc.name)),'command':(proc/'comm').read_text().strip()})
            except (OSError,PermissionError): pass
        print(json.dumps({'baseline':'1d609a710a7ba3c68d12b6d830d21b2344e3a7ca','killed_group':group,'lock_retained_after_sigkill_group':retained,'holders':holders,'job':str(job.id)}),flush=True)
finally:
    for worker,_ in processes: stop(worker,kill=True)
    amqp.close()
