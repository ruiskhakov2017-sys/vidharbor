import os,sys,subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
sys.path.insert(0,str(Path.cwd()/'scripts'))
from smoke_s01 import check_health,COMPOSE,BASE_URL
check_health('Clean start')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ['VIDHARBOR_CHROME'])
    page=browser.new_page()
    page.goto(BASE_URL)
    expect(page.locator('[data-testid="auth-screen"]')).to_be_visible()
    print('Playwright rendered Vue sign-in screen; replaces only the failing local Chromium --dump-dom CLI.',flush=True)
    browser.close()
for service,checks in (('rabbitmq',{'rabbitmq':False}),('db',{'postgres':False})):
    subprocess.run([*COMPOSE,'stop','--timeout','8',service],check=True,timeout=30)
    try: check_health(service+' stopped',**checks)
    finally: subprocess.run([*COMPOSE,'start',service],check=True,timeout=45)
    check_health(service+' restarted')
