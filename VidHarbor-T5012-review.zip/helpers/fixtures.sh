#!/usr/bin/env bash
set -euo pipefail
fixture_dir=/workspace/scratch/vidharbor-t5012/fixtures
mkdir -p "$fixture_dir"
ffmpeg -v error -y -f lavfi -i testsrc2=size=1280x720:rate=12 -f lavfi -i sine=frequency=440:sample_rate=44100 -t 25 -c:v libx264 -preset ultrafast -pix_fmt yuv420p -c:a aac "$fixture_dir/landscape.mp4"
ffmpeg -v error -y -f lavfi -i testsrc2=size=320x180:rate=12 -t 5 -c:v libvpx-vp9 -b:v 250k "$fixture_dir/small.webm"
ffmpeg -v error -y -i "$fixture_dir/landscape.mp4" -c copy "$fixture_dir/sample.mkv"
ffmpeg -v error -y -display_rotation:v:0 90 -i "$fixture_dir/landscape.mp4" -c:v copy -an "$fixture_dir/rotated.mov"
chmod 644 "$fixture_dir"/*
