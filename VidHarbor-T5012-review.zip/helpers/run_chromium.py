import os,sys,runpy
from pathlib import Path
from playwright.sync_api import BrowserType
original=BrowserType.launch
def launch(self,*args,**kwargs):
    if kwargs.get('channel')=='chrome':
        kwargs.pop('channel')
        kwargs['executable_path']=os.environ['VIDHARBOR_CHROME']
    return original(self,*args,**kwargs)
BrowserType.launch=launch
script=sys.argv[1];sys.argv=sys.argv[1:]
sys.path.insert(0,str(Path(script).resolve().parent))
print('Browser adaptation: requested Chrome channel uses installed Chromium executable; assertions unchanged.',flush=True)
runpy.run_path(script,run_name='__main__')
