import os,sys,uuid
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
sys.path.insert(0,str(Path.cwd()/'scripts'))
from smoke_s04 import BASE,FIXTURES,login_via_ui,upload_http,verify_hls,verify_playback,require
expect.set_options(timeout=45000)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ['VIDHARBOR_CHROME'])
    page=browser.new_page()
    suffix=uuid.uuid4().hex[:8]
    login_via_ui(page,'regression-'+suffix,uuid.uuid4().hex)
    jobs={name:upload_http(page.request,Path('/workspace/scratch/vidharbor-t5012/fixtures')/name,label+' '+suffix) for name,(label,_,_) in FIXTURES.items()}
    page.reload()
    expect(page.get_by_role('link',name='Готово · Смотреть')).to_have_count(4,timeout=240000)
    guest=p.request.new_context()
    details={name:verify_hls(guest,name,jobs[name],label+' '+suffix) for name,(label,_,_) in FIXTURES.items()}
    found=require(guest.get(BASE+'/api/catalog',params={'q':'гОРИЗОНТ '+suffix})).json()
    assert found=={'videos':[details['landscape.mp4']]}
    absent=str(uuid.uuid4())
    for path in (f'/watch/{absent}',f'/media/{absent}/master.m3u8',f'/api/catalog/{absent}'):
        require(guest.get(BASE+path),404)
    for name in ('landscape.mp4','rotated.mov','small.webm'):
        verify_playback(page,details[name],FIXTURES[name][1])
    print('S04 regression: real MP4/MOV/MKV/WebM uploads, HTTP playlists/segments, H264/AAC dimensions, private paths, search, absent IDs, Chromium',browser.version,'Auto/manual played.',flush=True)
    guest.dispose();browser.close()
