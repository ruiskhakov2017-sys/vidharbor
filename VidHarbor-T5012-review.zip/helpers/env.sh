export COMPOSE_PROJECT_NAME=vidharbor-t5012
export VIDHARBOR_PORT=8107
export VIDHARBOR_DB_NAME=vidharbor_s04_test
export VIDHARBOR_SECRETS_DIR=/workspace/scratch/vidharbor-t5012/secrets
export VIDHARBOR_PUBLIC_BASE_URL=http://127.0.0.1:8107
export VIDHARBOR_CHROME=/usr/bin/chromium
