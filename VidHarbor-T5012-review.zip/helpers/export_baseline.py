from pathlib import Path
import subprocess
base=Path('/workspace/scratch/vidharbor-t5012/baseline-api')
base.mkdir(exist_ok=True);base.chmod(0o755)
sha='1d609a710a7ba3c68d12b6d830d21b2344e3a7ca'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',sha,'--','api'],text=True).splitlines()
for name in paths:
    path=base/Path(name).relative_to('api')
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(subprocess.check_output(['git','show',sha+':'+name]));path.chmod(0o644)
for path in base.rglob('*'):
    if path.is_dir(): path.chmod(0o755)
