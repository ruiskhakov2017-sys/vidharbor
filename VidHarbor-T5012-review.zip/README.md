# VidHarbor T501.2 — пакет независимого Review

База: 1d609a710a7ba3c68d12b6d830d21b2344e3a7ca. Ветка feature/s05-completion. Изменения не закоммичены и не опубликованы. Пакет содержит только T501.2, его проверки и документацию. T502/T503 и S06 не начинались.

Реализованы: повтор по исходному failed_job_id из прежнего оригинала, уникальный nullable Job.retry_of, атомарные generation/job/outbox, права/CSRF, проверка файла и UI устойчивого повтора запроса. Старый запрос возвращает прежний job даже после нового FAILED/READY, без новой обработки.

PASS: 33 Django-теста (18 новых) на PostgreSQL; реальный HTTP/AMQP/FFmpeg/HLS; lost reply и broker outage; конкурентное создание (201+200+200+200); поздний replay; сохранность SHA/inode/mtime/Upload/URL; миграции fresh и 0003->0004; TypeScript/Vite; S02; выбранные S04/переименование проверки в Chromium. Два terminal event проверены в настоящей DLQ с теми же ID/payload.

Открытый риск: общий smoke_s04_faults.py FAIL на orphan/flock. Целевой probe на неизменённой базе воспроизвёл удержание lock отдельным процессом timeout после killpg. Новый код не исправляет supervisor S04. Полный PASS S04 не заявляется. Нужны независимая оценка и отдельное решение по базовому отказу.

Исходный S01 CLI Chromium дал ошибку/timeout; те же health-assertions и экран входа проверены с Playwright, результат вынесен отдельно. Нативные Chrome/Edge/Firefox, 3–5 ГБ, полный набор таймеров и внешний n8n/Sheets не проверялись в этом проходе.

## Состав

- changes.patch — полный diff к базе, включая все новые файлы; проверен reverse --check на текущем дереве.
- full-files.txt — полный diff и итоговое содержимое всех 17 файлов.
- files/ — итоговые файлы с путями относительно репозитория.
- logs/ — успешные и неуспешные фактические прогоны; детали в протоколе.
- helpers/ — конфигурация облачного стенда и дополнительные harness. Секреты, медиа, зависимости и дампы исключены.
- manifest.json — SHA-256 файлов и доказательств.

Начать с files/docs/homework-05/protocols/s05-reprocessing.md, затем reprocessing.py, migration 0004 и тестов. Для применения выбрать либо changes.patch к указанной базе, либо итоговые файлы; не применять оба способа подряд. Пакет не подтверждает согласование или merge.

## Воспроизведение

Linux/Bash, Docker Compose/BuildKit, Python с Playwright, системный Chromium и FFmpeg/ffprobe. Код из пакета должен быть в /workspace/vidharbor-s05-completion. Helpers рассчитаны на /workspace/scratch/vidharbor-t5012; при другом расположении адаптировать пути в копии. Этот проект должен быть отдельным тестовым: не направлять команды на рабочие volumes/секреты/сервисы.

Скопировать helpers в указанный каталог, выполнить prepare.py (создаёт новые локальные случайные секреты, значения не входят в пакет), fixtures.sh; дать root каталогу/fixtures режим 755, самим fixture — 644. Для сохранённых томов повторно использовать прежние секреты. Source env.sh, build/up и основные проверки приведены в протоколе. Не переносить содержимое чужих рабочих пространств.

Upgrade: создать пустую БД vidharbor_s05_upgrade через createdb в этом проекте и выполнить scripts/check_t5012_upgrade.py в upload с DB_NAME=vidharbor_s05_upgrade, PYTHONPATH=/app. Скрипт сам создаёт схему 0003 и существующие записи, затем обновляет до 0004; запускать один раз в пустой БД. Для shell-скрипта в /review нужен читаемый copy и override compose.json с volume.

S01: regress_s01.py сохраняет исходные check_health/COMPOSE и меняет только браузерную CLI-проверку на Playwright. S02: остановить только тестовые worker/relay/rabbitmq, запустить scripts/smoke_s02.py с двумя небольшими fixture, затем вернуть брокер. S04: regress_s04.py использует исходные verify_hls/verify_playback на четырёх реальных форматах; run_chromium.py адаптирует только отсутствующий Chrome executable для исходного READY rename smoke.

Baseline orphan: export_baseline.py извлекает API строго из базового SHA; probe_s04_orphan.py запускается в том же upload image с baseline-api, смонтированным read-only в /app, PYTHONPATH=/app:/review. Перед ним остановить тестовые worker/relay. Его результат является диагностикой FAIL, а не исправлением. Полный исходный S04 fault script запускался при NO_PROXY/no_proxy с добавленными внутренними web/api/upload/db/rabbitmq.

Фактические прогоны и ограничения описаны в протоколе, а не выводятся только из наличия команд. Новый запуск должен сохранять собственные exit codes/журналы и SHA кода.

## Поправка после предварительного Review

Тестовый помощник fail() переименован в mark_job_failed(); стандартный unittest.TestCase.fail() больше не перекрывается. Искусственное выставление SUCCEEDED/READY явно обозначено как unit-проверка receipt, а не HLS-публикации. Отдельный реальный smoke_t5012 остаётся доказательством FFmpeg/HLS. После правки все 33 Django-теста прошли за 8,186 с; logs/django-review-fix.log. Приложение не менялось. FAIL orphan/flock и статус независимого Review сохранены. Commit/push/PR не выполнялись.
